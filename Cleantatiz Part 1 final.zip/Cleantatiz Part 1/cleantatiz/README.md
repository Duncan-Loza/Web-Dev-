# Cleantatiz Website

## Student Information

**Student Name:** Duncan Loza

**Student Number:** St10527661

**Module:** Wede5020w

**Module Code:** 5020

---

## Project Overview

This project is a website developed for **Cleantatiz**, a local cleaning business that provides cleaning services for homes, properties and vehicles.

The purpose of the project is to create an online presence for the business and make it easier for potential customers to find information about the organisation, view its services, check service availability, view the price list and get in contact with the business.

The website was developed as part of the Part 1 requirements and includes the planning and initial HTML development stages of the website project.

---

## Website Goals and Objectives

The main goals of the Cleantatiz website are to:

* Provide information about Cleantatiz.
* Clearly explain the cleaning services offered.
* Display the available price list.
* Provide information about service availability.
* Provide the business contact information.
* Make it easy for customers to enquire about cleaning services.
* Keep the website navigation simple and consistent.
* Create a clear and user-friendly website structure.
* Provide information suitable for customers requiring cleaning services for homes, properties and vehicles.

---

## Target Audience

The target audience for the website includes:

* Homeowners
* Tenants
* Property owners
* Customers requiring property cleaning
* Customers requiring upholstery and carpet cleaning
* Customers requiring mattress and window cleaning
* Customers requiring vehicle cleaning
* Customers in the areas served by Cleantatiz

The website is designed to provide these users with access to information about Cleantatiz and the cleaning services available.

---

## Website Structure

The website consists of five main HTML pages:

### 1. Home (`index.html`)

The Home page introduces Cleantatiz and includes:

* Business introduction
* Overview of the cleaning services
* Service information
* Price list
* Contact information
* Navigation to the other website pages

### 2. About (`about.html`)

The About page provides information about:

* Cleantatiz
* The organisation's cleaning services
* The types of customers and properties it assists
* The different services offered
* The organisation's goal
* Images related to Cleantatiz

### 3. Services (`services.html`)

The Services page provides information about the cleaning services, including:

* Upholstery Cleaning
* Carpet Cleaning
* Mattress Cleaning
* Window Cleaning
* Spring and Deep Cleaning
* Pre / Post Occupation Cleaning
* Mobile Car Wash

The page also includes the supplied Cleantatiz price list.

### 4. Service Areas (`service-areas.html`)

The Service Areas page provides information about service availability.

The page explains that customers should provide their suburb or location when making an enquiry so that Cleantatiz can confirm whether the required service is available in their area.

Specific service areas were not included where they were not provided in the organisation information.

### 5. Contact (`contact.html`)

The Contact page provides customers with the Cleantatiz contact information.

The page includes:

* Contact details
* Telephone numbers
* Email address
* Service area enquiry information
* Basic quote enquiry form
* Service selection
* Customer location
* Preferred date
* Customer message

**Joy:** 065 384 8002

**Kevin:** 062 550 5536

**Email:** [cleantatizcleaning@gmail.com](mailto:cleantatizcleaning@gmail.com)

---

## Sitemap

The website sitemap is structured as follows:

```text
Home
├── About
├── Services
├── Service Areas
└── Contact
```

---

## Services

The main services included on the website are:

* Upholstery Cleaning
* Carpet Cleaning
* Mattress Cleaning
* Window Cleaning
* Spring and Deep Cleaning
* Pre / Post Occupation Cleaning
* Mobile Car Wash

---

## Project Files

The main project files include:

```text
Cleantatiz
│
├── index.html
├── about.html
├── services.html
├── service-areas.html
├── contact.html
│
└── images
    ├── Cleantatiz cleaning image
    └── Cleantatiz price list
```

The HTML files contain the basic website structure and content required for the Part 1 development stage.

---

## Contact Information

**Joy:** 065 384 8002

**Kevin:** 062 550 5536

**Email:** [cleantatizcleaning@gmail.com](mailto:cleantatizcleaning@gmail.com)

---

## Part 1 Development

The Part 1 version of the website focuses on establishing the basic HTML foundation of the Cleantatiz website.

The project includes:

* HTML page structure
* Website navigation
* Organisation information
* Service information
* Service area information
* Contact information
* Images and content assets
* Basic enquiry form
* Sitemap structure

Further styling and functionality can be developed during the later stages of the website project.
